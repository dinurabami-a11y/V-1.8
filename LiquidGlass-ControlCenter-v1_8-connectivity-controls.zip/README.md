# Glass Control Center

A liquid-glass control center for Android, built on top of
[QWEA0/Liquid-Glass-Android](https://github.com/QWEA0/Liquid-Glass-Android) (MIT).

Swipe down from the top-right corner of any screen. Needs Android 10+ (the glass lens needs Android 13+).

## v1.7

- Fixed the expanded-control backdrop edge: the full-screen control-center stage no longer scales down while the expanded tile animates, which could expose a rectangular strip around the screen.
- Reduced the extra dim overlay from 45% to 26% so the live background stays clearer during expansion.
- Removed `FLAG_LAYOUT_NO_LIMITS` from the full-screen panel window and anchored it at the display's top-left. This avoids oversized or offset overlay bounds on devices that handled the accessibility window differently.
- The expanded glass tile keeps its spring animation; only the full-screen background layer remains fixed to the display edges.

## v1.6

- Strengthened the compact-button lens: the AGSL shader now refracts across the face of each small glass control, not only in a thin edge band.
- Replaced the previous seven-sample rainbow dispersion with a restrained three-sample edge separation to reduce GPU texture reads.
- Removed decorative green, yellow, rainbow, red, blue and purple button fills. Enabled controls now use a neutral pearly glass highlight while retaining clear state feedback.
- Neutralized the expanded media-card tint and improved the low-feature fallback veil.

## v1.5

- Real liquid glass: every tile bends a picture with a lens shader (refraction at the edges, colour boost), live on the GPU, no screenshots.
- The picture is chosen in the app (step 4) or a built-in colourful gradient is used. Needs Android 13+ for the lens; older phones keep the v1.4 look.
- Lens maths adapted from Kyant0's AndroidLiquidGlass (Apache License 2.0).

## v1.4

- Liquid glass material: clearer tiles, lighter dim, curved bright rim, darkened edge, colour fringe, and a light that follows your finger.
- Long-press the connectivity block, the torch button, the volume / brightness sliders or the media card and they bloom into a bigger glass view with a springy overshoot.
- Torch brightness slider (Android 13+ phones that support torch levels).

## v1.3
* **Real background blur.** The panel window asks Android to blur whatever is behind it (`FLAG_BLUR_BEHIND`,
  Android 12+). It is live and follows the screen; **no screenshots are taken any more** (the "take screenshot"
  accessibility permission was removed). Without system blur support the backdrop is just darker.
* **iOS 26 layout**, copied from the reference screenshot: connectivity block, media block, rotation/silent
  toggles, volume + brightness sliders, Focus pill, 4x3 grid of round glass buttons, status row, header.
* New `GlassTile` view paints the glass (tint gradient, inner glow, specular rim).
* Buttons squish on touch-down and bounce back; toggles cross-fade colour and pop the icon.

## Layout
* `liquidglass/` - the original library, unchanged
* `app/` - the control center (accessibility-overlay service + setup screen)

Build: `./gradlew :app:assembleRelease` (JDK 17, Android SDK 36, NDK 27.0.12077973, CMake 3.22.1)

## Getting the APK without Android Studio
Every push builds the app on GitHub: open the **Actions** tab -> latest run -> **Artifacts** -> `GlassControlCenter-apk`.
Push a tag such as `v1.3` and the APK is also attached to a **Release** (easy download link on your phone).
You can also press **Run workflow** in the Actions tab to build on demand.


## v1.8 connectivity and expansion fixes

- Long-pressing an individual connectivity control now uses that control as the expansion origin.
- The expanded connectivity sheet is positioned adaptively in the middle-right of the measured display.
- Wi-Fi and NFC use Android floating Settings panels; airplane mode and mobile data use the floating Internet panel.
- Bluetooth, hotspot, VPN and Battery Saver open Android Quick Settings instead of navigating straight to general Settings pages.
- The expanded hotspot row avoids claiming an inaccurate Off state when the OEM blocks hotspot-state access.
- Added the camera permission request path needed for flashlight control.

Android restricts ordinary third-party apps from silently toggling Wi-Fi (Android 10+), and Bluetooth for apps targeting Android 13+. Some protected system controls still require a user action in Android's own panel or Quick Settings.
