package com.liquidglass.controlcenter

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import androidx.annotation.RequiresApi
import kotlin.math.max
import kotlin.math.min

/**
 * A rounded liquid-glass tile. On Android 13+ it refracts the chosen backdrop picture through
 * LiquidLens; on devices where that is unavailable, it uses a translucent glass fallback.
 */
class GlassTile(
    context: Context,
    private val radius: Float,
    private val topTint: Int = DEFAULT_TOP,
    private val bottomTint: Int = DEFAULT_BOTTOM,
    private val tintStop: Float = 0.5f
) : FrameLayout(context) {

    companion object {
        const val DEFAULT_TOP = 0x18FFFFFF
        const val DEFAULT_BOTTOM = 0x05FFFFFF
    }

    private val d = context.resources.displayMetrics.density

    private val shape = Path()
    private val rimRect = RectF()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    // Neutral fallback veil. Saturated per-control colours are intentionally avoided;
    // the picture and the specular rim provide the colour and glass character.
    private val fallbackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x1AFFFFFF
    }

    // Crisp 1.2dp outer specular rim.
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
    }

    // Subtle dark outer lip for 3D depth separation.
    private val lipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.0f * d
        color = 0x33000000
    }

    // Touch spotlight.
    private val touchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val touchMatrix = Matrix()
    private var touchShader: RadialGradient? = null
    private var touchX = 0f
    private var touchY = 0f
    private var touchAlpha = 0f
    private var touchAnim: ValueAnimator? = null

    private var cornerPx = 0f

    private val liquidPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lens: Any? = null
    private var lensFailed = false
    private val loc = IntArray(2)

    init {
        setWillNotDraw(false)
        clipChildren = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        cornerPx = min(radius, min(wf, hf) / 2f)

        shape.reset()
        shape.addRoundRect(0f, 0f, wf, hf, cornerPx, cornerPx, Path.Direction.CW)

        // Subtle top-to-bottom light sheen. Keep tintStop meaningful for existing callers.
        val stop = tintStop.coerceIn(0.01f, 0.99f)
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(topTint, bottomTint, bottomTint),
            floatArrayOf(0f, stop, 1f),
            Shader.TileMode.CLAMP
        )

        val strokeOffset = rimPaint.strokeWidth / 2f
        rimRect.set(strokeOffset, strokeOffset, wf - strokeOffset, hf - strokeOffset)

        // Bright top-left edge fading into a softer bottom-right highlight.
        rimPaint.shader = LinearGradient(
            0f, 0f, wf * 0.4f, hf,
            intArrayOf(
                0x99FFFFFF.toInt(),
                0x33FFFFFF,
                0x1AFFFFFF,
                0x4DFFFFFF
            ),
            floatArrayOf(0f, 0.4f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )

        // Interactive touch light. Its shader is reused while dragging.
        val tr = min(max(min(wf, hf) * 0.85f, 56f * d), 130f * d)
        val ts = RadialGradient(
            0f, 0f, tr,
            intArrayOf(0x40FFFFFF, 0x14FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        touchShader = ts
        touchPaint.shader = ts
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchX = ev.x
                touchY = ev.y
                animateTouch(1f, 110L)
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = ev.x
                touchY = ev.y
                if (touchAlpha > 0f) invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animateTouch(0f, 450L)
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun animateTouch(target: Float, duration: Long) {
        touchAnim?.cancel()
        val animator = ValueAnimator.ofFloat(touchAlpha, target)
        animator.duration = duration
        animator.addUpdateListener {
            touchAlpha = it.animatedValue as Float
            invalidate()
        }
        touchAnim = animator
        animator.start()
    }

    override fun onDetachedFromWindow() {
        touchAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        var liquid = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !lensFailed) {
            liquid = drawLiquid(canvas)
        }

        if (!liquid) {
            // Fallback base is drawn along the rounded path, preserving transparent corners.
            canvas.drawPath(shape, fallbackPaint)
            fillPaint.alpha = 255
            canvas.drawPath(shape, fillPaint)
        } else {
            // A minimal veil keeps the refracted backdrop clear and colourful.
            fillPaint.alpha = 25
            canvas.drawPath(shape, fillPaint)
            fillPaint.alpha = 255
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun drawLiquid(canvas: Canvas): Boolean {
        val bmp = LiquidBackdrop.glass ?: return false
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f || bmp.width <= 0 || bmp.height <= 0) return false

        return try {
            val rv = rootView
            if (rv.width <= 0 || rv.height <= 0) return false

            var currentLens = lens as? LiquidLens
            if (currentLens == null) {
                currentLens = LiquidLens()
                lens = currentLens
            }

            getLocationInWindow(loc)

            var scale = 1f
            var view: View? = this
            while (view != null) {
                scale *= view.scaleX
                view = view.parent as? View
            }
            if (scale < 0.05f) return false

            val kx = rv.width.toFloat() / bmp.width
            val ky = rv.height.toFloat() / bmp.height

            // Curved bevel depth and negative magnification for the refracted edge.
            val refractionHeight = min(22f * d, min(w, h) * 0.45f)
            val refractionAmount = -min(55f * d, min(w, h) * 0.75f)

            currentLens.bind(bmp, LiquidBackdrop.version)
            currentLens.apply(
                liquidPaint, w, h, cornerPx,
                kx / scale, ky / scale, -loc[0] / scale, -loc[1] / scale,
                refractionHeight, refractionAmount,
                // A restrained, uniform dispersion keeps the rim glassy without rainbow
                // fringes on individual controls (and costs less GPU work than the old split).
                chromaticAberration = 0.22f
            )
            canvas.drawPath(shape, liquidPaint)
            true
        } catch (_: Throwable) {
            lensFailed = true
            false
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas) // Draw icons and sliders before the glass highlights.

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Interactive finger spotlight.
        val shader = touchShader
        if (shader != null && touchAlpha > 0.003f) {
            touchMatrix.setTranslate(touchX, touchY)
            shader.setLocalMatrix(touchMatrix)
            touchPaint.alpha = (touchAlpha * 255f).toInt().coerceIn(0, 255)
            canvas.drawPath(shape, touchPaint)
        }

        val strokeOffset = rimPaint.strokeWidth / 2f
        val radius = max(0f, cornerPx - strokeOffset)

        // 1. Subtle dark lip.
        canvas.drawRoundRect(rimRect, radius, radius, lipPaint)

        // 2. Crisp 3D specular edge.
        canvas.drawRoundRect(rimRect, radius, radius, rimPaint)
    }
}
