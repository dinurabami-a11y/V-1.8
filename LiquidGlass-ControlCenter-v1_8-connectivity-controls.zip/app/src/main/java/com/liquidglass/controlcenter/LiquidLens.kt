package com.liquidglass.controlcenter

/**
 * The lens: bends the backdrop picture near the glass edge (refraction), with optional chromatic dispersion and rim lighting.
 *
 * The base shader mathematics is adapted from Kyant0's AndroidLiquidGlass library, Apache License 2.0:
 *   https://github.com/Kyant0/AndroidLiquidGlass
 *   Copyright 2025 Kyant
 */
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
class LiquidLens {

    private val shader = RuntimeShader(LENS_AGSL)
    private var bitmapShader: BitmapShader? = null
    private var boundVersion = -1
    private val matrix = Matrix()

    fun bind(bmp: Bitmap, version: Int) {
        if (version == boundVersion && bitmapShader != null) return
        val bs = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        bs.setFilterMode(BitmapShader.FILTER_MODE_LINEAR)
        bitmapShader = bs
        boundVersion = version
    }

    fun apply(
        paint: Paint, w: Float, h: Float, corner: Float,
        sx: Float, sy: Float, tx: Float, ty: Float,
        refractionHeight: Float, refractionAmount: Float,
        chromaticAberration: Float = 0.22f
    ) {
        val bs = bitmapShader ?: return
        matrix.setScale(sx, sy)
        matrix.postTranslate(tx, ty)
        bs.setLocalMatrix(matrix)
        shader.setInputShader("content", bs)
        shader.setFloatUniform("size", w, h)
        shader.setFloatUniform("cornerRadius", corner)
        shader.setFloatUniform("refractionHeight", refractionHeight)
        shader.setFloatUniform("refractionAmount", refractionAmount)
        shader.setFloatUniform("chromaticAberration", chromaticAberration)
        paint.shader = shader
    }

    companion object {
        private const val LENS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float cornerRadius;
uniform float refractionHeight;
uniform float refractionAmount;
uniform float chromaticAberration;

float sdRoundedRect(float2 coord, float2 halfSize, float radius) {
    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));
    float outside = length(max(cornerCoord, 0.0)) - radius;
    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);
    return outside + inside;
}

float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {
    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));
    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {
        return sign(coord) * normalize(max(cornerCoord, 0.0));
    } else {
        float gradX = step(cornerCoord.y, cornerCoord.x);
        return sign(coord) * float2(gradX, 1.0 - gradX);
    }
}

float circleMap(float x) {
    return 1.0 - sqrt(max(0.0, 1.0 - x * x));
}

half4 main(float2 coord) {
    float2 halfSize = size * 0.5;
    float2 centered = coord - halfSize;
    float sd = sdRoundedRect(centered, halfSize, cornerRadius);

    float2 sampleCoord = coord;
    float edgeFactor = 0.0;
    float2 grad = float2(0.0, -1.0);

    if (-sd < refractionHeight) {
        float normalizedDist = clamp(-sd / max(refractionHeight, 1.0), 0.0, 1.0);
        edgeFactor = 1.0 - normalizedDist;
        float d = circleMap(edgeFactor) * refractionAmount;
        float gradRadius = min(cornerRadius * 1.5, min(halfSize.x, halfSize.y));
        grad = normalize(gradSdRoundedRect(centered, halfSize, gradRadius) + 0.35 * normalize(centered));
        sampleCoord = coord + d * grad;
    }

    // A shallow convex-lens bulge across the WHOLE surface. The old shader only
    // displaced pixels in a narrow band at the edge, so small round buttons read as
    // flat frosted plastic. This radial map makes the backdrop visibly magnify/bend
    // through the centre of compact controls as well as at their bevel.
    float minHalf = max(1.0, min(halfSize.x, halfSize.y));
    float bodyDepth = clamp(-sd / minHalf, 0.0, 1.0);
    float2 radial = centered / max(length(centered), 1.0);
    float bodyBulge = sin(bodyDepth * 3.14159265) * min(minHalf * 0.20, 22.0);
    sampleCoord -= radial * bodyBulge;

    // Three texture taps give a restrained wavelength split at the bevel. This replaces
    // the previous seven-tap rainbow treatment and reduces GPU sampling on older phones.
    float2 dispersion = grad * chromaticAberration * edgeFactor * 0.55;
    half4 baseSample = content.eval(sampleCoord);
    half4 redSample = content.eval(sampleCoord + dispersion);
    half4 blueSample = content.eval(sampleCoord - dispersion);
    half4 color = half4(redSample.r, baseSample.g, blueSample.b, baseSample.a);

    // Keep the background vivid and readable rather than burying it under a grey wash.
    half l = dot(color.rgb, half3(0.2126, 0.7152, 0.0722));
    color.rgb = mix(half3(l), color.rgb, 1.28);
    color.rgb = mix(color.rgb, half3(0.055, 0.060, 0.075), 0.09);

    // A soft broad reflection across the upper face, plus the sharper curved rim below.
    float2 uv = coord / max(size, float2(1.0));
    float sheenLine = uv.x * 0.72 + uv.y * 0.62;
    float sheen = exp(-pow((sheenLine - 0.34) * 8.0, 2.0)) * 0.075;
    color.rgb += half3(sheen);

    // 3D Specular Highlight on curved rim (Light coming from top-left)
    if (edgeFactor > 0.0) {
        float2 lightDir = normalize(float2(-0.4, -0.9));
        float specular = max(0.0, dot(-grad, lightDir));
        float glint = pow(specular, 3.6) * pow(edgeFactor, 1.35) * 0.52;
        color.rgb += half3(glint);
    }

    return half4(color.rgb, 1.0);
}
"""
    }
}
