package com.liquidglass.controlcenter

import android.app.Activity
import android.Manifest
import android.content.pm.PackageManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private const val REQ_PICK = 71
private const val REQ_CAMERA = 72

/** Simple setup screen: shows what is enabled and gives one-tap shortcuts to the right settings pages. */
class MainActivity : Activity() {

    private lateinit var serviceStatus: TextView
    private lateinit var writeStatus: TextView

    private val green = 0xFF64CB6E.toInt()
    private val red = 0xFFEC6B69.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(28), dp(24), dp(40))

        col.addView(text("Glass Control Center  v1.8", 28f, bold = true, color = 0xFFFFFFFF.toInt()))
        col.addView(text("Swipe down from the top-right corner of any screen to open it.", 15f, color = 0xFFB8B8C4.toInt(), top = 6))

        // ---- step 1 ----
        col.addView(heading("1  Turn on the service"))
        serviceStatus = text("", 15f, bold = true)
        col.addView(serviceStatus)
        col.addView(text("Accessibility \u2192 Glass Control Center \u2192 switch ON. The blurred background is made live by Android itself (Android 12+). No screenshots are taken; nothing is saved or sent anywhere.", 14f, color = 0xFFB8B8C4.toInt(), top = 4))
        col.addView(button("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(text("Switch greyed out? Open App info \u2192 \u22EE (top-right) \u2192 \"Allow restricted settings\", then try again.", 13f, color = 0xFF8E8E9A.toInt(), top = 8))
        col.addView(button("Open App info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // ---- step 2 ----
        col.addView(heading("2  Allow brightness & rotation control"))
        writeStatus = text("", 15f, bold = true)
        col.addView(writeStatus)
        col.addView(button("Allow modify system settings") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(text("Optional: the Focus button and the silent (bell) button use Do Not Disturb.", 13f, color = 0xFF8E8E9A.toInt(), top = 12))
        col.addView(button("Allow Do Not Disturb access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        // ---- step 3 ----
        col.addView(heading("3  Allow flashlight access"))
        col.addView(text("The flashlight uses Android's camera torch API. Grant camera permission so its button can control the LED. The app does not take photos or record video.", 14f, color = 0xFFB8B8C4.toInt(), top = 4))
        col.addView(button("Grant flashlight permission") {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Flashlight permission is already granted.", Toast.LENGTH_SHORT).show()
            } else {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            }
        })

        // ---- step 4 ----
        col.addView(heading("4  Keep it running (Honor)"))
        col.addView(text("Settings \u2192 Battery \u2192 App launch \u2192 Glass Control Center \u2192 turn off \"Manage automatically\" and allow all three switches. Also lock the app in Recents.", 14f, color = 0xFFB8B8C4.toInt(), top = 4))

        // ---- step 5 ----
        col.addView(heading("5  Picture behind the glass"))
        col.addView(text("Real liquid glass bends a picture. Android never lets an app read other apps, so the control center shows a picture of your choice behind the glass (a colourful wallpaper looks best). Nothing is captured from your screen.", 14f, color = 0xFFB8B8C4.toInt(), top = 4))
        col.addView(button("Choose picture") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "image/*"
            startActivityForResult(i, REQ_PICK)
        })
        col.addView(button("Use the built-in colours") {
            LiquidBackdrop.clearPicture(this)
            LiquidBackdrop.reload(this)
            Toast.makeText(this, "Built-in colours are back.", Toast.LENGTH_SHORT).show()
        })

        // ---- tips ----
        col.addView(heading("How to use"))
        col.addView(text("\u2022 Pull down from the top-right corner, release to settle.\n\u2022 Swipe up or tap empty space to close.\n\u2022 Wi-Fi opens Android's floating Wi-Fi panel; Airplane Mode and mobile data use the floating Internet panel; NFC uses its floating panel.\n\u2022 Bluetooth, hotspot, VPN and Battery Saver open Android Quick Settings. Android blocks ordinary apps from silently switching these protected radios and modes.\n\u2022 Rotation, Focus, silent mode, brightness, volume and flashlight are controlled directly when their permissions are granted.\n\u2022 Display and Accessibility remain shortcuts to their dedicated system pages.\n\u2022 If the background is dark instead of blurry: Android only blurs windows when \"window blur\" is allowed (not in battery saver, and not on every phone).\n\u2022 If Honor's own control center opens instead, make sure step 1 is ON.", 14f, color = 0xFFB8B8C4.toInt(), top = 4))

        val scroll = ScrollView(this)
        scroll.addView(col)
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }
        setContentView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Preparing the picture\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = LiquidBackdrop.importPicture(this, uri)
            runOnUiThread {
                if (ok) {
                    LiquidBackdrop.reload(this)
                    Toast.makeText(this, "Done. Pull down the control center to see it.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Could not read that picture.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        val enabled = isServiceEnabled()
        serviceStatus.text = if (enabled) "\u2713 Service is ON" else "\u2717 Service is OFF"
        serviceStatus.setTextColor(if (enabled) green else red)
        val canWrite = Settings.System.canWrite(this)
        writeStatus.text = if (canWrite) "\u2713 Allowed" else "\u2717 Not allowed yet"
        writeStatus.setTextColor(if (canWrite) green else red)
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, ControlCenterService::class.java)
        for (part in enabled.split(':')) {
            val cn = ComponentName.unflattenFromString(part)
            if (cn != null && cn == me) return true
        }
        return false
    }

    private fun text(s: String, sp: Float, bold: Boolean = false, color: Int = 0xFFFFFFFF.toInt(), top: Int = 0): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) }
        return t
    }

    private fun heading(s: String): TextView {
        val t = text(s, 18f, bold = true, top = 28)
        t.gravity = Gravity.START
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        return b
    }
}
